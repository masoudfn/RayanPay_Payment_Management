﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Rayanpay.Ipg.Core.Models;

namespace Rayanpay.Ipg.Core.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        private string baseUrl;
        private string username;
        private string password;
        private string clientId;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
            this.baseUrl = configuration.GetSection("PaymentManagementConfig")["BaseUrl"];
            this.username = configuration.GetSection("PaymentManagementConfig")["UserName"];
            this.password = configuration.GetSection("PaymentManagementConfig")["Password"];
            this.clientId = configuration.GetSection("PaymentManagementConfig")["ClientId"];
        }

        public IActionResult Index()
        {
            ViewBag.BaseUrl = baseUrl;
            ViewBag.UserName = username;
            ViewBag.Password = password;
            ViewBag.ClientId = clientId;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Pay()
        {
            try
            {
                var authToken = GenerateAuthorizationToken();

                var startResponse = Start(authToken, 100002, "", 100, $"{Request.Scheme}://{Request.Host}/Home/IpgPaymentHandler?refrId={100002}", 10000, false);

                await Response.WriteAsync(startResponse.BankRedirectHtml);

                return View();

            }
            catch (Exception ex)
            {
                return View("Error", ex.Message);
            }
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> IpgPaymentHandler([FromQuery]long refrId)
        {
            try
            {
                var requestHeaders = new List<string>();
                var requestFormItems = new List<string>();
                if (Request.Headers != null && Request.Headers.Count > 0)
                {
                    requestHeaders.AddRange(Request.Headers.Where(x => requestHeaders.All(r => r != x.Key)).Select(x => $"{x.Key}={x.Value}"));
                }

                if (Request.Form != null && Request.Form.Count > 0)
                {
                    requestFormItems.AddRange(Request.Form.Where(x => requestFormItems.All(r => r != x.Key)).Select(x => $"{x.Key}={x.Value}"));
                }

                var body = Request.HasFormContentType ? string.Join("&", requestFormItems.OrderBy(x => x)) : new StreamReader(Request.Body, Encoding.UTF8).ReadToEnd();
                var header = string.Join("&", requestHeaders.OrderBy(x => x));


                var response = ResponseParse(refrId, header, body);

                ViewBag.Result = new ResultModel
                {
                    Date = response.EndDate?.ToLongDateString(),
                    PaymentId = response.PaymentId.ToString(),
                    Status = response.RayanHttpStatusCode.ToString()
                };

                return View("Result");
            }
            catch (Exception ex)
            {

                return View("Error", "عملیات پرداخت با خطا موجه شد");
            };
        }

        private string GenerateAuthorizationToken()
        {
            var client = new HttpClient()
            {
                BaseAddress = new Uri(baseUrl)
            };
            var request = new
            {
                clientId = clientId,
                userName = username,
                password = password
            };

            var response = client.PostAsync("api/v1/auth/token/generate", new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json")).Result;
            if (response.IsSuccessStatusCode)
            {
                return response.Content.ReadAsStringAsync().Result;
            }

            return string.Empty;
        }
        private OnlinePaymentInfoResponse Start(string authToken, long refId, string msisdn, int gatewayId, string callBackUrl, long amount, bool gateSwitchingAllowed)
        {
            var request = new
            {
                referenceId = refId,
                amount = amount,
                msisdn = msisdn,
                gatewayId = gatewayId,
                callbackUrl = callBackUrl,
                gateSwitchingAllowed = gateSwitchingAllowed,
            };

            var client = new HttpClient()
            {
                BaseAddress = new Uri(baseUrl)
            };
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
            var response = client.PostAsync("api/v1/ipg/payment/start", new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json")).Result;

            var options = new JsonSerializerOptions
            {
                ReadCommentHandling = JsonCommentHandling.Skip,
                PropertyNameCaseInsensitive = true
            };
            var result = JsonSerializer.Deserialize<OnlinePaymentInfoResponse>(response.Content.ReadAsStringAsync().Result, options);

            result.RayanHttpStatusCode = (int)response.StatusCode;

            return result;
        }
        private BankProcessInfoResponse ResponseParse(long referenceId, string header, string body)
        {
            var client = new HttpClient()
            {
                BaseAddress = new Uri(baseUrl)
            };
            var authToken = GenerateAuthorizationToken();

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
            var request = new
            {
                referenceId = referenceId,
                header = header,
                content = body
            };

            var response = client.PostAsync("api/v1/ipg/payment/response/parse", new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json")).Result;

            var result = JsonSerializer.Deserialize<BankProcessInfoResponse>(response.Content.ReadAsStringAsync().Result);

            result.RayanHttpStatusCode = (int)response.StatusCode;

            return result;
        }


    }
}
