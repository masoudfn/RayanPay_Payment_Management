﻿using System;

namespace Rayanpay.Ipg.Core.Models
{
    internal class BankProcessInfoResponse
    {
        public long PaymentId { get; set; }
        public int RayanHttpStatusCode { get; set; }
        public string HashedBankCardNumber { get; set; }
        public DateTime? EndDate { get; set; }
        public int Status { get; set; }
    }
}