﻿namespace Rayanpay.Ipg.Core.Models
{
    public class ResultModel
    {
        public string PaymentId { get; set; }
        public string Date { get; set; }
        public string Status { get; set; }
    }
}
