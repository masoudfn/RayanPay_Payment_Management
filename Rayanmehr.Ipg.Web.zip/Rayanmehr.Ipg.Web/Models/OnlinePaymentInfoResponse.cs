﻿namespace Rayanpay.Ipg.Web.Models
{
    internal class OnlinePaymentInfoResponse
    {
        public long PaymentId { get; set; }
        public int RayanHttpStatusCode { get; set; }
        public string BankRedirectHtml { get; set; }

    }
}