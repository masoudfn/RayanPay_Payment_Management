﻿namespace Rayanpay.Ipg.Web.Models
{
    public class PaymentManagementConfig
    {
        public string UserName;
        public string Password;
        public string ClientId;
        public string BaseUrl;
    }
}